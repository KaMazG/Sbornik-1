﻿using System;
using System.Collections.Generic;

namespace Sbornik_1_5_isp_5
{
    class Program
    {
        static void Main()
        {
            try
            {
                Zadanie8_3();
            }
            catch (Exception)
            {
                Console.WriteLine("Случилась ошибка, рестарт программы");
                Console.ReadKey();
                Console.Clear();
                Main();
            }
        }
        static public void Zadanie1_3()
        {
            Console.WriteLine("Введите число");
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine($"Вы ввели число: {number}");
        }       //1 
        static public void Zadanie1_28()
        {
            Console.WriteLine("Введите длину ребра");
            double rebro = double.Parse(Console.ReadLine());
            Console.WriteLine($"Объем: {Math.Pow(rebro, 3)}\nПлощадь: {6 * Math.Pow(rebro, 2)} ");
        }      //2 
        static public void Zadanie1_53()
        {
            int monitor = 6000;
            int sysblock = 35000;
            int keyboard = 2000;
            int mouse = 1600;
            int computer = monitor + sysblock + keyboard + mouse;
            Console.WriteLine($"Стоимость монитора: {monitor}\nСтоимость системного блока: {sysblock}\nСтоимость клавиатуры: {keyboard}\nСтоимость мыши: {mouse} ");
            Console.WriteLine("Введите число компьютеров");
            int computers = int.Parse(Console.ReadLine());
            int result = computer * computers;
            Console.WriteLine($"3 компьютера: {3 * computer}\n{computers} компьютеров: {result}");
        }      //3
        static public void Zadanie2_3()
        {
            Console.WriteLine("Введите массу в кг");
            double kg = double.Parse(Console.ReadLine());
            double tons = kg / 1000;
            Console.WriteLine($"Всего тонн: {tons}");
        }       //4
        static public void Zadanie2_28()
        {
            List<char> numbers = new List<char>(3);
            Console.WriteLine("Введите число");
            string number = Console.ReadLine();

            for (int i = 0; i < number.Length; i++)
                numbers.Add(number[i]);
            numbers.RemoveAt(1);
            numbers[2] = numbers[1];
            numbers[1] = numbers[0];
            numbers[0] = numbers[2];
            string result = null;
            for (int i = 0; i < numbers.Count; i++)
            {
                result += numbers[i];
            }
            Console.WriteLine(result);

        }      //5
        static public void Zadanie3_3()
        {
            bool A = true;
            bool B = false;
            bool C = false;

            bool resultA = !A & B;
            bool resultB = A | !B;
            bool resultC = A & B | C;
            Console.WriteLine($"a) {resultA}\nb) {resultB}\nc) {resultC}");
        }       //6
        static public void Zadanie3_28()
        {
            Console.WriteLine("Введите А");
            int A = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите B");
            int B = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите C");
            int C = int.Parse(Console.ReadLine());
            Console.WriteLine($"a) {A > 100 & B > 100}");
            Console.WriteLine($"б) {(A % 2 == 0 & B % 2 != 0) | (A % 2 != 0 & B % 2 == 0)}");
            Console.WriteLine($"в) {A > 0 | B > 0}");
            Console.WriteLine($"г) {A % 3 == 0 & B % 3 == 0 & C % 3 == 0}");
            Console.WriteLine($"д) {(A < 50 & B > 50 & C > 50) | (A > 50 & B < 50 & C > 50) | (A > 50 & B > 50 & C < 50)  }");
            Console.WriteLine($"е) {A < 0 | B < 0 | C < 0}");
        }      //7
        static public void Zadanie4_3()
        {
            Console.WriteLine("Введите x");
            double x = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите y");
            double y = double.Parse(Console.ReadLine());
            if (x > 4)
                Console.WriteLine("В области II");
            else
                Console.WriteLine("В области I");
        }       //8
        static public void Zadanie4_28()
        {
            Console.WriteLine("Введите трехзначное число");
            string number = Console.ReadLine();
            if (int.Parse(number[0].ToString()) > int.Parse(number[2].ToString()))
                Console.WriteLine("а) Больше первая цифра");
            else
                Console.WriteLine("а) Больше последняя цифра");
            if (int.Parse(number[0].ToString()) > int.Parse(number[1].ToString()))
                Console.WriteLine("б) Больше первая цифра");
            else
                Console.WriteLine("б) Больше вторая цифра");
            if (int.Parse(number[1].ToString()) > int.Parse(number[2].ToString()))
                Console.WriteLine("в) Больше вторая цифра");
            else
                Console.WriteLine("в) Больше последняя цифра");
        }      //9
        static public void Zadanie4_53()
        {
            double a = 3.42461;
            double b = 5.3714;
            double c = 2.9821;
            double x = 10.3918;
            double y = 12.4813;
            double brick = a * b * c;
            double hole = x * y;
            if (hole > brick)
                Console.WriteLine("Пролезет");
            else
                Console.WriteLine("Не пролезет");
        }      //10
        static public void Zadanie4_78()
        {
            Console.WriteLine("Введите первое число");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите второе число");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите третье число");
            int c = int.Parse(Console.ReadLine());
            if (a % 2 == 0)
                Console.WriteLine(a);
            if (b % 2 == 0)
                Console.WriteLine(b);
            if (c % 2 == 0)
                Console.WriteLine(c);
        }      //11
        static public void Zadanie4_103()
        {
            Console.WriteLine("Введите первое число");
            double a = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите второе число");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите третье число");
            double c = double.Parse(Console.ReadLine());
            double max = b;
            if (a > b)
                max = a;
            if (a < c)
                max = c;
            Console.WriteLine($"Максимальное число: {max}");
        }     //12
        static public void Zadanie4_128()
        {
            int month = 0;
            int years = 0;
            Console.WriteLine("Введите месяцы");
            month = int.Parse(Console.ReadLine());
            if (month < 1 | month > 1188)
                Zadanie4_128();
            for (int i = 11; month > i;)
            {
                years++;
                month -= 12;
            }
            Console.WriteLine($"Возраст: {years} лет {month} месяцев");

        }     //13
        static public void Zadanie5_3()
        {
            Console.WriteLine("a)");
            for (int i = 20; i < 36; i++)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("б)");
            Console.WriteLine("Введите b");
            double b = double.Parse(Console.ReadLine());
            for (int i = 10; i <= b; i++)
            {
                Console.WriteLine(Math.Pow(i, 2));
            }

            Console.WriteLine("в)");
            Console.WriteLine("Введите a");
            double a = double.Parse(Console.ReadLine());
            for (int i = 50; i <= a; i++)
            {
                Console.WriteLine(Math.Pow(i, 3));
            }

            Console.WriteLine("г)");
            Console.WriteLine("Введите a");
            int a1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите b");
            int b1 = int.Parse(Console.ReadLine());
            for (int i = a1; i <= b1; i++)
            {
                Console.WriteLine(i);
            }
        }       //14
        static public void Zadanie5_28()
        {
            Console.WriteLine("a)");
            double multiple = 8;
            for (int i = 8; i < 16; i++)
                Console.WriteLine(multiple *= i);

            Console.WriteLine("б)");
            int a = 0;
            do
            {
                Console.WriteLine("Введите a");
                a = int.Parse(Console.ReadLine());
            }
            while (a < 1 | a > 20);
            double multiple1 = a;
            for (int i = a; i < 20; i++)
                Console.WriteLine(multiple1 *= i);

            Console.WriteLine("в)");
            int b = 0;
            do
            {
                Console.WriteLine("Введите b");
                b = int.Parse(Console.ReadLine());
            }
            while (b < 1 | b > 20);
            double multiple2 = 1;
            for (int i = 1; i <= b; i++)
                Console.WriteLine(multiple2 *= i);

            Console.WriteLine("г)");
            int a1 = 0;
            Console.WriteLine("Введите a");
            a1 = int.Parse(Console.ReadLine());
            int b1 = 0;
            Console.WriteLine("Введите b");
            b1 = int.Parse(Console.ReadLine());
            double multiple3 = a1;
            for (int i = a1; i <= b1; i++)
                Console.WriteLine(multiple3 *= i);
        }      //15
        static public void Zadanie5_53()
        {
            int[] degree = new int[10] { 2, 3, 5, 3, 4, 5, 5, 5, 4, 5 };
            double result = 0;
            for (int i = 0; i < degree.Length; i++)
            {
                result += degree[i];
                Console.WriteLine($"Оценка №{i + 1}: {degree[i]}");
            }
            Console.WriteLine($"Средняя оценка: {result / degree.Length}");
        }      //16
        static public void Zadanie5_78()
        {
            double x1 = 360;
            double x2 = 90;
            Console.WriteLine($"Абсцисса певой точки: {x1}, абсцисса второй точки: {x2}");
            Console.WriteLine($"Площадь: {Math.Cos(x1) - Math.Cos(x2)}");
        }      //17
        static public void Zadanie6_3()
        {
            int[] mass = new int[5] { 3, 20, 13, 15, 17 };
            int checker = 0;
            int sum = 0;
            for (int i = 0; i < mass.Length; i++)
            {
                checker = mass[i] % 2;
                sum += mass[i] * checker;
            }
            Console.WriteLine(sum);
        }       //18
        static public void Zadanie6_28()
        {
            int number = 57283;
            int max = 9999;
            int min = 9999;
            char[] numeric = number.ToString().ToCharArray();
            for (int i = numeric.Length - 1; i > 0; i--)
            {
                max = int.Parse(numeric[i].ToString());
                for (int j = numeric.Length - 1; j > 0; j--)
                {
                    if (int.Parse(numeric[i].ToString()) < int.Parse(numeric[j].ToString()))
                    {
                        max = int.Parse(numeric[j].ToString());
                    }

                }
            }
            Console.WriteLine($"а) От конца числа: {max}");

            for (int i = 0; i < numeric.Length; i++)
            {
                max = int.Parse(numeric[i].ToString());
                for (int j = 0; j < numeric.Length; j++)
                {
                    if (int.Parse(numeric[i].ToString()) < int.Parse(numeric[j].ToString()))
                    {
                        max = int.Parse(numeric[j].ToString());
                    }

                }
            }

            Console.WriteLine($"а) От начала числа: {max}");

            for (int i = numeric.Length - 1; i > 0; i--)
            {
                min = int.Parse(numeric[i].ToString());
                for (int j = numeric.Length - 1; j > 0; j--)
                {
                    if (int.Parse(numeric[i].ToString()) > int.Parse(numeric[j].ToString()))
                    {
                        min = int.Parse(numeric[j].ToString());
                    }

                }
            }
            Console.WriteLine($"б) От конца числа: {min}");

            for (int i = 0; i < numeric.Length; i++)
            {
                min = int.Parse(numeric[i].ToString());
                for (int j = 0; j < numeric.Length; j++)
                {
                    if (int.Parse(numeric[i].ToString()) > int.Parse(numeric[j].ToString()))
                    {
                        min = int.Parse(numeric[j].ToString());
                    }

                }
            }

            Console.WriteLine($"б) От начала числа: {min}");


        }      //19
        static public void Zadanie6_53()
        {
            int number = 9663;
            bool IsSorted = true;
            char[] numeric = number.ToString().ToCharArray();
            for (int i = numeric.Length - 1; i > 0; i--)
            {
                if (int.Parse(numeric[i].ToString()) >= int.Parse(numeric[i - 1].ToString()))
                {
                    IsSorted = false;
                }
            }
            Console.WriteLine($"Последовательность упорядочена: {IsSorted}");
        }      //20
        static public void Zadanie6_78()
        {
            int first = 10;
            int step = 2;
            Console.WriteLine($"Введите число m, первый член - {first}, шаг - {step}");
            int m = int.Parse(Console.ReadLine());
            bool flag = false;

            for (int i = first; i <= m; i += step)
            {
                if (i == m)
                    flag = true;
            }
            Console.WriteLine($"Член является частью последовательности: {flag}");
        }      //21
        static public void Zadanie6_103()
        {
            double a = 9;
            double b = 16;
            double p = 0;
            double q = 0;

            for (int i = 0; i <= a; i++)
            {
                p++;
                q = 0;
                for (int j = 0; j <= b; j++)
                {
                    q++;
                    if ((a % p == 0) & b % q == 0 & p != 1 & q != 1 & p != a & q != b)
                        Console.WriteLine($"Дробь {a}|{b} можно сократить на {p}|{q}");
                }
            }

        }     //22
        static public void Zadanie7_3()
        {
            int[] mass = new int[10] { 20, 56, 11, 24, 45, 86, 34, 43, 5, 6 };
            int sum = 0;
            for (int i = 0; i < mass.Length; i++)
            {
                if (mass[i] < 50)
                    sum += mass[i];
            }
            Console.WriteLine(sum);
        }       //23
        static public void Zadanie7_28()
        {
            int p = 6;
            int[] mass = new int[10] { 12, 3, 4, 6, 9, 32, 1, 35, 45, 105 };
            int countA = 0;
            int countB = 0;
            int countC = 0;
            for (int i = 0; i < mass.Length; i++)
            {
                if (mass[i] > p)
                    countA++;
            }

            for (int i = 0; i < mass.Length; i++)
            {
                char[] temp = mass[i].ToString().ToCharArray();
                for (int j = 0; j < temp.Length; j++)
                    if (temp[temp.Length - 1] == '5')
                    {
                        countB++;
                        break;
                    }
            }

            for (int i = 0; i < mass.Length; i++)
            {
                if (mass[i] % 2 == 0)
                    countC++;
            }
            Console.WriteLine($"a) {countA} чисел\nб) {countB} чисел\nв) {countC} чисел\n");
        }      //24
        static public void Zadanie7_53()
        {
            int[] massMax = new int[5] { 2, 5, 6, 6, 4 };
            int[] massMin = new int[5] { 2, 2, 6, 6, 4 };
            int max = 0;
            int min = int.MaxValue;
            int MaxNumber = 0;
            int MinNumber = 0;

            for (int i = 0; i < massMax.Length; i++)
            {
                for (int j = 0; j < massMax.Length; j++)
                {
                    if (massMax[j] >= max)
                        max = massMax[j];
                }
                if (massMax[i] == max)
                {
                    for (int j = 0; j < massMax.Length; j++)
                    {
                        if (massMax[j] == max & massMax[i] == max)
                            i++;
                    }
                    MaxNumber = i + 1;


                }

            }

            for (int i = 0; i < massMin.Length; i++)
            {
                for (int j = 0; j < massMin.Length; j++)
                {
                    if (massMin[j] <= min)
                        min = massMin[j];
                }
                if (massMin[i] == min)
                {
                    for (int j = 0; j < massMin.Length; j++)
                    {
                        if (massMin[j] == min & massMin[i] == min)
                            break;
                    }
                    MinNumber = i + 1;
                    break;
                }

            }
            Console.WriteLine($"а) Максимальное под номером {MaxNumber}\nб) Минимальное под номером {MinNumber}");
        }      //25
        static public void Zadanie7_78()
        {
            int[] mass = new int[10] { 2, 4, 8, 16, 32, 64, 128, 136, 260, 450 };
            List<int> lenght = new List<int>();
            int max = 0;
            for (int i = 0; i < mass.Length - 1; i++)
            {
                lenght.Add(mass[i + 1] - mass[i]);
            }
            for (int i = 0; i < lenght.Count; i++)
            {
                if (lenght[i] > max)
                    max = lenght[i];
            }
            Console.WriteLine($"Максимальная длина: {max}");

        }      //26
        static public void Zadanie7_103()
        {
            int[] mass = new int[10] { 3, 5, 6, 7, 2, -5, -3, -4, -2, -1 };
            bool NotPositive = true;
            int count = 0;
            for (int i = 0; i < mass.Length; i++)
            {
                if (mass[i] > 0)
                    count++;
            }
            if (count > 5)
                NotPositive = false;
            Console.WriteLine($"Положительных чисел меньше 5: {NotPositive}");
        }     //27
        static public void Zadanie7_128()
        {
            int number = 6;
            int[] dividers = new int[3] { 1, 2, 3 };
            int sum = 0;
            for (int i = 0; i < dividers.Length; i++)
                sum += dividers[i];
            if (number == sum)
                Console.WriteLine("Число совершенно");
            else
                Console.WriteLine("Число несовершенно");
        }     //28
        static public void Zadanie8_3()
        {
            
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine();
                for (int j = 1; j <= i; j++)
                {
                    Console.Write($"{i} ");
                }
            }
            Console.WriteLine();
            for (int i = 5; i <= 9; i++)
            {
                Console.WriteLine();
                for (int j = 9; j >= i; j--)
                {
                    Console.Write($"{i} ");
                }
            }
            Console.WriteLine();
            for (int i = 10; i <= 50; i+=10)
            {
                Console.WriteLine();
                for (int j = 10; j <= i; j+=10)
                {
                    Console.Write($"{i} ");
                }
            }
            Console.WriteLine();
            for (int i = 5; i <= 25; i+=5)
            {
                Console.WriteLine();
                for (int j = 25; j >= i; j-=5)
                {
                    Console.Write($"{i} ");
                }
            }
        }       //29
        static public void Zadanie8_28()
        {

            for (int i = 200; i <= 500; i++)
            {
                int count = 0;
                for (int j = 1; j <= i; j++)
                    if (i % j == 0)
                        count++;
                if (count == 6)
                    Console.WriteLine($"Число: {i}");
            }
        }      //30
        static public void Zadanie8_52()
        {
            double needCattle = 100;
            double money = 100;
            double telenok = 0;
            for (double i = 0; i <= (money / 10); i++)
                for (double j = 0; j <= ((money - i * 10) / 5); j++)
                {
                    telenok = (money - i * 10 - j * 5) * 2;
                    if ((i + j + telenok) == needCattle & (i * 10 + j * 5 + telenok * 0.5) == money)
                    {
                        money -= (i * 10 + j * 5 + telenok * 0.5);
                        needCattle = i + j + telenok;
                        Console.WriteLine($"Быки: {i}\nКоровы: {j}\nТелята: {telenok}");
                        Console.WriteLine($"Денег осталось: {money}");
                        Console.WriteLine($"Закуплено скота: {needCattle}");
                        break;

                    }

                }
        }      //31
        static public void Zadanie9_3()
        {
            Console.WriteLine("Введите сначала имя, затем фамилию");
            string name = Console.ReadLine();
            string family = Console.ReadLine();
            char[] result = (name + family).ToCharArray();
            for (int i = 0; i < result.Length; i++)
                Console.Write(result[i]);
        }       //32
        static public void Zadanie9_28()
        {
            string word = "трос";
            char[] word1 = { word[3], word[2], word[1], word[0] };
            char[] word2 = { word[1], word[2], word[3], word[0], };
            char[] word3 = { word[0], word[2], word[1], word[3] };
            for (int i = 0; i < word1.Length; i++)
                Console.Write($"{word1[i]}");
            Console.WriteLine();
            for (int i = 0; i < word2.Length; i++)
                Console.Write($"{word2[i]}");
            Console.WriteLine();
            for (int i = 0; i < word3.Length; i++)
                Console.Write($"{word3[i]}");
        }      //33
        static public void Zadanie9_53()
        {
            string sentence = "Дано предложение. Вывести столбиком его третий, шестой и т. д. символы";
            for (int i = 0; i < sentence.Length; i += 3)
                Console.WriteLine(sentence[i]);
        }      //34
        static public void Zadanie9_78()
        {
            string word = "казак";
            string changeling = "";
            bool isChangeling = true;
            for (int i = word.Length - 1; i >= 0; i--)
                changeling += word[i];
            if (changeling != word)
                isChangeling = false;
            Console.WriteLine($"Слово {word} перевертыш: {isChangeling}");
        }      //35
        static public void Zadanie9_103()
        {
            string word = "ежик";
            string newWord = "";
            Console.WriteLine($"Исходное слово: {word}");
            for (int i = 0; i < word.Length - 1; i += 2)
            {
                newWord += word[i + 1];
                newWord += word[i];
            }
            Console.WriteLine($"Получившееся слово: {newWord}");
        }     //36
        static public void Zadanie9_128()
        {
            string word = "Автомобиль";
            string newWord = "";
            char first = word[0];
            int k = 6;
            Console.WriteLine($"Исходное слово: {word}, заменяемая буква под номером: {k}");
            for (int i = 0; i <= word.Length - 2; i++)
            {
                if (i != k - 1)
                    newWord += word[i + 1];
                else
                {
                    newWord += first;
                    newWord += word[i + 1];

                }
            }
            Console.WriteLine($"Получившееся слово: {newWord}");
        }     //37
        static public void Zadanie9_154()
        {
            string word = "казак";
            int count = 0;
            string Symbols = string.Empty;
            for (int i = 0; i < word.Length - 1; i++)
            {
                for (int j = 0; j < word.Length - 1; j++)
                {
                    if (!Symbols.Contains(word[i]))
                    {
                        Symbols += word[i];
                        count++;
                        break;
                    }

                }

            }
            Console.WriteLine($"В слове {word} уникальных букв: {count}");
        }     //38
        static public void Zadanie9_178()
        {
            string EnteredString = "Дано предложение. Напечатать все его слова, предварительно преобразовав";
            string[] newString = EnteredString.Split(" ");

            Console.WriteLine($"Данное предложение: {EnteredString}");
            Console.Write($"а) Слова из предложения: ");
            for (int i = 0; i < newString.Length; i++)
            {
                char[] CharA = newString[i].ToCharArray();
                for (int j = 0; j < newString[i].Length; j++)
                {
                    if (CharA[j] == 'а')
                    {
                        CharA[j] = newString[i].ToCharArray()[j] = 'о';
                        break;
                    }
                }
                for (int j = 0; j < CharA.Length; j++)
                {
                    Console.Write($"{CharA[j]}");
                }
                Console.Write(" ");
            }
            Console.WriteLine();

            Console.Write($"б) Слова из предложения: ");
            for (int i = 0; i < newString.Length; i++)
            {
                char[] CharB = newString[i].ToCharArray();
                for (int j = 0; j < newString[i].Length; j++)
                {
                    if (CharB[j] == CharB[CharB.Length - 1] & j != CharB.Length - 1)
                    {
                        CharB[j] = ' ';
                        break;
                    }
                }
                for (int j = 0; j < CharB.Length; j++)
                {
                    Console.Write($"{CharB[j]}");
                }
                Console.Write(" ");
            }
            Console.WriteLine();

            Console.Write($"в) Слова из предложения: ");
            for (int i = 0; i < newString.Length; i++)
            {
                string temp = string.Empty;
                char[] CharC = newString[i].ToCharArray();
                for (int j = 0; j < newString[i].Length; j++)
                {
                    if (!temp.Contains(CharC[j]))
                    {
                        temp += CharC[j];
                        continue;
                    }
                    if (temp.Contains(CharC[j]))
                    {
                        CharC[j] = ' ';
                    }
                }
                for (int j = 0; j < CharC.Length; j++)
                {
                    Console.Write($"{CharC[j]}");
                }
                Console.Write(" ");
            }
            Console.WriteLine();

            string maxString = "";
            Console.Write($"г) Измененное слово: ");
            for (int i = 0; i < newString.Length; i++)
            {
                if (newString[i].Length > maxString.Length)
                {
                    maxString = newString[i];
                }
            }
            char[] CharG = maxString.ToCharArray();
            for (int i = 0; i < CharG.Length; i++)
            {
                if (i == CharG.Length / 2)
                {
                    CharG[i] = ' ';
                }

            }
            for (int i = 0; i < CharG.Length; i++)
            {
                Console.Write($"{CharG[i]}");
            }
            Console.Write(" ");
        }     //39
        static public void Zadanie10_3()
        {
            int[] valuesX = new int[5] { 2, 5, 4, -3, 1 };
            int[] valuesY = new int[5] { 4, 8, 7, -3, 3 };
            int maxX = 0;
            int maxY = 0;
            int functMaxX = 0;
            int functMaxY = 0;
            for (int i = 0; i < valuesX.Length; i++)
                Console.WriteLine($"Значения x{i}: {valuesX[i]}");
            for (int i = 0; i < valuesY.Length; i++)
                Console.WriteLine($"Значения y{i}: {valuesY[i]}");
            for (int i = 0; i < valuesX.Length; i++)
                if (valuesX[i] > maxX)
                    maxX = valuesX[i];
            for (int i = 0; i < valuesY.Length; i++)
                if (valuesY[i] > maxY)
                    maxY = valuesY[i];
            Console.WriteLine($"\n1) Максимальный x: {maxX}\nМаксимальный y: {maxY}");
            for (int i = 0; i < valuesX.Length; i++)
                Console.WriteLine($"Ответ {i + 1}: {2 * valuesY[i] * (2 * maxX - maxY)}");

            for (int i = 0; i < valuesX.Length; i++)
                for (int j = 0; j < valuesX.Length; j++)
                {
                    if (Math.Max(valuesX[i], valuesX[j]) > functMaxX)
                        functMaxX = Math.Max(valuesX[i], valuesX[j]);
                }
            for (int i = 0; i < valuesY.Length; i++)
                for (int j = 0; j < valuesY.Length; j++)
                {
                    if (Math.Max(valuesY[i], valuesY[j]) > functMaxY)
                        functMaxY = Math.Max(valuesY[i], valuesY[j]);
                }
            Console.WriteLine($"\n2) Максимальный x: {functMaxX}\nМаксимальный y: {functMaxY}");
            for (int i = 0; i < valuesX.Length; i++)
                Console.WriteLine($"Ответ {i + 1}: {2 * valuesY[i] * (2 * functMaxX - functMaxY)}");
        }      //40
        static public void Zadanie10_28()        //41
        {
            string first = "Даны 2 предложения";
            string second = "Найти общее количество букв н в них";
            Console.WriteLine($"Предложения: \n{first}\n{second}");
            Console.WriteLine($"Общее количество букв н: {Zadanie10_28_func(first, second)}");
        }
        static public int Zadanie10_28_func(string first, string second)    //41 функция
        {
            int count = 0;
            for (int i = 0; i < first.Length; i++)
                if (first[i] == 'н' | first[i] == 'Н')
                    count++;
            for (int i = 0; i < second.Length; i++)
                if (second[i] == 'н' | second[i] == 'Н')
                    count++;
            return count;
        }
        static public void Zadanie10_53()
        {
            Zadanie10_53_func(Console.ReadKey().KeyChar);
        } //42
        public static List<char> numbers = new List<char>();
        static public void Zadanie10_53_func(char number)
        {

            if (number != '0')
            {
                numbers.Add(number);
                Zadanie10_53_func(Console.ReadKey().KeyChar);
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Последовательность: ");
                for (int i = numbers.Count - 1; i >= 0; i--)
                {
                    Console.Write(numbers[i]);
                }
            }


        } //42 функция
        static public void Zadanie11_3()
        {
            Random random = new Random();
            double[] mass1 = new double[15];
            double[] mass2 = new double[15];
            double[] mass3 = new double[15];
            double[] mass4 = new double[15];
            Console.WriteLine("а) ");
            for (int i = 0; i < mass1.Length; i++)
            {
                mass1[i] = random.NextDouble();
                Console.WriteLine(mass1[i]);
            }
            Console.WriteLine("б) ");
            for (int i = 0; i < mass1.Length; i++)
            {
                mass1[i] = random.NextDouble() + 22;
                Console.WriteLine(mass1[i]);
            }
            Console.WriteLine("в) ");
            for (int i = 0; i < mass1.Length; i++)
            {
                mass1[i] = random.NextDouble() * 10;
                Console.WriteLine(mass1[i]);
            }
            Console.WriteLine("г) ");
            for (int i = 0; i < mass1.Length; i++)
            {
                mass1[i] = random.NextDouble() * 100 - 50;
                Console.WriteLine(mass1[i]);
            }
        } //43
        static public void Zadanie11_28()
        {
            Random random = new Random();
            int sum = 0;
            int[] mass = new int[10];
            for (int i = 0; i < mass.Length; i++)
            {
                mass[i] = random.Next(-10, 10);
                Console.WriteLine($"{i+1}-ый элемент массива: {mass[i]}");
                sum += mass[i];
            }
            if (sum >= 0)
                Console.WriteLine($"Сумма элементов {sum} положительна");
            else
                Console.WriteLine($"Сумма элементов {sum} отрицательна");
        } //44
        static public void Zadanie11_53()
        {
            int m = 5;
            int n = 10;
            int[] mass = new int[10] { 20, 100, 33, 56, 98, 12, 5, 10, 4, 7 };
            for(int i = 0; i < mass.Length; i++)
            {
                Console.WriteLine($"{i}-ый элемент массива: {mass[i]}");
            }
            Console.WriteLine($"Массив после изменений, m = {m}, n = {n}:");
            for(int i = 0; i < mass.Length; i++)
            {
                if (mass[i] % 10 == 0)
                    mass[i] = 0;
                if (mass[i] % 2 != 0)
                    mass[i] *= 2;
                else if (mass[i] % 2 == 0 & mass[i] != 0)
                    mass[i] /= 2;
                if (mass[i] % 2 != 0)
                    mass[i] -= m;
                if (i % 2 != 0 & mass[i] != 0)
                    mass[i] += n;
            }
            for (int i = 0; i < mass.Length; i++)
            {
                Console.WriteLine($"{i}-ый элемент массива: {mass[i]}");
            }

        } //45
    }
}
